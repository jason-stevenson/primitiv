primitiv
========
